const help = (prefix) => { 
	return `
╭───᯽─┈ ┈ ┈┈ ┈╮
┊𝖴𝗉𝖽𝖺𝗍𝖾 𝖵4.678.09
┃┈┈╭────────╯
┃𝖭𝖺𝗆𝖺 : X-BoTz
┃𝖯𝗋𝖾𝖿𝗂𝗑 : ❴ / ❵
┃𝖠𝗎𝗍𝗁𝗈𝗋 : Rio Gansss
┃𝖨𝗇𝗌𝗍𝖺𝗀𝗋𝖺𝗆 : coming soon
┃𝖶𝗁𝖺𝗍𝗌𝖺𝗉𝗉 : https://bit.ly/2Yq4Efk
┃Repair : Update 29-11-2021
┃Made : Since 13-11-2019
┃𝖻𝖾𝖿𝗈𝗋𝖾 : SaDBoTz
╰─────────────────┈ ❁ཻུ۪۪⸙͎
𝖳𝖧𝖭𝖷 𝖲𝖴𝖣𝖠𝖧 𝖬𝖤𝖭𝖦𝖦𝖴𝖭𝖠𝖪𝖠𝖭 𝖡𝖮𝖳
──────────────᯽────╯
╭┈──────𝖱𝖴𝖫𝖤𝖲
╰─➤⚒𝖱𝖴𝖫𝖤𝖲📜
↣𝖣𝗂 𝖫𝖺𝗋𝖺𝗇𝗀 𝖳𝗅𝗉 𝖻𝗈𝗍 : 𝖡𝖺𝗇+𝖡𝗅𝗈𝖼𝗄
↣𝖣𝗂𝗅𝖺𝗋𝖺𝗇𝗀 𝖲𝗉𝖺𝗆 : 𝖡𝖺𝗇
↣𝖩𝖺𝗇𝗀𝖺𝗇 𝖢𝗁𝖺𝗍 𝖯𝗋𝗂𝖻𝖺𝖽𝗂 
↣𝖯𝖾𝗌𝖺𝗇 𝖽𝗂 𝗃𝖾𝖽𝖺 2 𝖽𝖾𝗍𝗂𝗄
─────────────᯽────╯
╭┈─────FITUR X-BoTz
╰─❁۪۪
╰─➤ *${prefix}ownerbot*
╰─➤ *${prefix}adminbot*
╰─➤ *${prefix}funmenu*
╰─➤ *${prefix}mediamenu*
╰─➤ *${prefix}kerangmenu*
╰─➤ *${prefix}makermenu*
╰─➤ *${prefix}othermenu*
╰─➤ *${prefix}animemenu*
╰─➤ *${prefix}nsfwmenu*
╰─➤ *${prefix}vipmenu*
───────────────᯽──╯
 ╭─➤ Subscribe Youtube :
 │☗ Rio_
 ╰─╯──────────᯽───╯
╰─➤ *${prefix}bugreport*
╰─➤  *${prefix}info*
╰─➤ *${prefix}owner*
╰─➤ *${prefix}request*
╰─➤ *${prefix}setprefix*
╰─➤ *${prefix}listblock*
╰─➤ *${prefix}iklan*
╰─➤ *${prefix}runtume*
╰─➤ *${prefix}rules*
╰─➤ *${prefix}tnc*
╰─➤ *${prefix}cekvip*
╰─➤ *${prefix}daftarvip*
╰─➤ *${prefix}addvip*
╰─➤ *${prefix}dellvip*
╰─➤ *${prefix}snk*
╰─➤ *${prefix}list*
╰─➤ *${prefix}𝚍𝚘𝚗𝚊𝚝𝚎*
╰─➤ *${prefix}fitnah*
╰─➤ *${prefix}totaluser*
╰─➤ *${prefix}level*
╰─➤ *${prefix}leveling*
╰─➤ *${prefix}glass*
──────────────᯽───╯
╭─➤ Follow Instagram :
│☗ coming soon
╰─╯──────────᯽───╯
╰─➤ *${prefix}apiteks [teks]*
╰─➤ *${prefix}airteks [teks]*
╰─➤ *${prefix}metalteks [teks]*
╰─➤ *${prefix}mlogo [teks]*
╰─➤ *${prefix}ffbaner [teks]*
╰─➤ *${prefix}embun [teks]*
╰─➤ *${prefix}kunciteks [teks]*
╰─➤ *${prefix}say*
╰─➤ *${prefix}addsay [teks]*
╰─➤ *${prefix}listsay*
╰─➤ *${prefix}bacot*
╰─➤ *${prefix}addbacot [teks]*
╰─➤ *${prefix}listbacot*
╰─➤ *${prefix}resetbacot*
╰─➤ *${prefix}aguse*
╰─➤ *${prefix}kicktime*
╰─➤ *${prefix}nobg*
╰─➤ *${prefix}url2img*
╭┈────────────᯽───╯
╰─➤𝖨𝗇𝖿𝗈 𝖴𝗉𝖽𝖺𝗍𝖾 :
➤ 𝖴𝗉𝖽𝖺𝗍𝖾 𝗉𝖺𝖽𝖺 29-01-2021
➤ 𝖲𝖾𝗐𝖺 𝖠𝗉𝗂 𝖪𝖾𝗒?
➤ 𝖡𝖾𝗅𝗂 𝖢𝗋𝖾𝖽𝗂𝗍 𝖦𝖺𝗆𝗂𝗇𝗀?
➤ 𝖡𝖾𝗅𝗂 𝖪𝖾𝖻𝗎𝗍𝗎𝗁𝖺𝗇 𝖲𝗈𝗌𝗆𝖾𝖽?
➤ 𝖩𝗈𝗂𝗇 𝖬𝖺𝗇𝖺𝗀𝖾𝗆𝖾𝗇𝗍 𝖲𝖾𝗅𝖾𝖻𝗀𝗋𝖺𝗆?
➤ 𝖩𝖺𝗌𝖺 𝖯𝗋𝗈𝗆𝗈𝗍𝖾 𝖶𝗁𝖺𝗍𝗌𝖠𝗉𝗉?
➤ 𝖯𝖯 𝖤𝗇𝖽𝗈𝗋𝗌𝖾 𝖨𝗇𝗌𝗍𝖺𝗀𝗋𝖺𝗆?
╭─╯
╰➤ 𝗉𝖼 https://api.whatsapp.com/send?phone=6283191156893
      
「𝖯𝖾𝗌𝖺𝗇 𝖦𝖺 𝗉𝖾𝗇𝗍𝗂𝗇𝗀 𝖻𝗅𝗈𝗄!」
   ╭┈──────────᯽───╯
   ╰─➤𝖲𝗉𝖾𝖼𝗂𝖺𝗅 𝖳𝗁𝖺𝗇𝗑 𝖳𝗈 :
   𝖬𝗁𝖺𝗇𝗄𝖡𝖺𝗋2
   𝖠𝗋𝗎𝗀𝖺
   𝖠𝖽𝗂𝗐𝖺𝗃𝗌𝗁𝗂𝗇𝗀
   𝗑𝗉𝗍𝗇
   𝗍𝗈𝖻𝗓
   𝗉𝖾𝗇𝗀𝗀𝗎𝗇𝖺 𝖻𝗈𝗍
   𝗆𝖺𝗌𝗅𝖾𝗇𝗍
   𝖼𝖺𝗅𝗂𝗉𝗁
   𝗋𝗂𝗓𝗄𝗒
   𝖠𝗋𝗂𝖿𝗂
   𝖭𝖺𝗓𝗐𝖺
   𝖳𝖺𝗌𝗒𝖺
   𝖠𝗀𝗎𝗌
   𝖠𝗅𝗅. 𝖢𝗋𝖾𝖺𝗍𝗈𝗋 𝖡𝗈𝗍 𝖫𝖺𝗂𝗇𝗇𝗒𝖺
   ───────────᯽────╯
   
             ▉▍▏▐▕ ▋▊▊▕║▕▉▉ ▋
             ▉▍▏▐▕ ▋▊▊▕║▕▉▉ ▋
                       
          ©️ *Arifi Razzaq*
             
`
}
exports.help = help
	