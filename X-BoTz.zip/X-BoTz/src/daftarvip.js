const daftarvip = (prefix) => { 
	return `
	
*HARGA DAFTAR VIP :*
-Rp. 5K > Akses Fitur ViP
-Rp. 10K > Fitur VIP + Masukin Bot KeGrup Kalian!

*JIKA INGIN DAFTAR VIP :*
*Chat Owner BOT :*
_https://bit.ly/2Yq4Efk atau ketik *${prefix}owner*

*NOTE*

*GRUP WHATSAPP BOT :*
_https://chat.whatsapp.com/JQq5FsTzji8ElR7O8TJzOl `
}
exports.daftarvip = daftarvip